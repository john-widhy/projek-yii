<?php
  echo "w";

?>