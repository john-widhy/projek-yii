<footer class="footer">
					<div class="container">
						<div class="row">
							<div class="col-12 text-center">
								<?php echo$title; ?> &copy; 2023 Made with <i class="fa fa-heart text-danger"></i> By <a href="ttps://wa.me/6281649363404" target="">WIDHY-REVOLUTION</a>
							</div>
						</div>
					</div>
				</footer>
			</div>
		</div>
		
		<script src="<?php echo$base_url; ?>views/site/vendor/js/jquery.core.js"></script>
		<script src="<?php echo$base_url; ?>views/site/vendor/js/jquery.app.js"></script>

	</body>
</html>